//
//  ViewController.swift
//  testapp
//
//  Created by MAC OS on 5/29/17.
//  Copyright © 2017 MAC OS. All rights reserved.
//

import UIKit
import  SwiftyJSON
class ViewController: UIViewController {

    var final: [String] = [""] ;
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.commentary%20where%20match_id%3D11985&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=");
        
        do
        {
            
        let  data1 = try  Data(contentsOf: url!)
            
            do
            {
            let json1 =  try JSON(data: data1);
                
              
                let cnt = json1["query"]["results"]["Over"].count;
                
                let cnt1 = json1["query"]["results"]["Over"][0]["Ball"].count;
                
                
                for i in 0 ..< cnt {
                    
                   
                    for j in 0 ..< cnt1 {
                        
                       
                        
                        let str1 = json1["query"]["results"]["Over"][0]["Ball"][j]["c"].string;
                        
                        
                        final.append(str1!);
                        
                        
                        
                        
                    }
                    
                    
                    
                }
                
                
                print(final);
                
                
                
               /* if let userName = json1["route"][0]["fullname"].string {
                    
                    print(userName);
                    
                    
                    //Now you got your value
                }
                
            */
            }
            catch
            {
                
                
            }
            
            
        
        }
        catch
        {
            
            
        }
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

